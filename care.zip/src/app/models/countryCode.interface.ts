export interface CountryCode {
  code: string;
  id: number;
}
